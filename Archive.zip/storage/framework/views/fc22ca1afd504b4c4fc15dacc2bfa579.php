<?php $__env->startSection('title', 'My Orders'); ?>

<?php $__env->startSection('content'); ?>
<?php
$statusConfig = [
    'pending'    => ['label' => 'Pending',    'class' => 'bg-yellow-100 text-yellow-800', 'icon' => 'clock'],
    'processing' => ['label' => 'Processing', 'class' => 'bg-blue-100 text-blue-800',   'icon' => 'package'],
    'shipped'    => ['label' => 'Shipped',    'class' => 'bg-purple-100 text-purple-800','icon' => 'truck'],
    'delivered'  => ['label' => 'Delivered',  'class' => 'bg-indigo-100 text-indigo-800','icon' => 'map-pin'],
    'completed'  => ['label' => 'Completed',  'class' => 'bg-green-100 text-green-800', 'icon' => 'check-circle-2'],
    'cancelled'  => ['label' => 'Cancelled',  'class' => 'bg-red-100 text-red-800',     'icon' => 'x-circle'],
];
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
    
    <!-- Sidebar -->
    <div class="w-full md:w-64 flex-shrink-0">
        <div class="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden sticky top-24">
            <div class="p-5 border-b border-gray-50 dark:border-gray-700 text-center">
                <div class="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center text-2xl font-bold mx-auto mb-3">
                    <?php echo e(strtoupper(substr(auth()->user()->name ?? auth()->user()->phone, 0, 1))); ?>

                </div>
                <h3 class="font-bold text-gray-900 dark:text-white truncate"><?php echo e(auth()->user()->name !== 'Customer' ? auth()->user()->name : auth()->user()->phone); ?></h3>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo e(auth()->user()->phone); ?></p>
            </div>
            <div class="p-2">
                <a href="<?php echo e(route('account.orders')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors bg-primary/5 text-primary">
                    <i data-lucide="package" class="w-5 h-5"></i> My Orders
                </a>
                <a href="<?php echo e(route('account.addresses')); ?>" class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <i data-lucide="map-pin" class="w-5 h-5"></i> Saved Addresses
                </a>
                <form action="<?php echo e(route('account.logout')); ?>" method="POST" class="mt-2 pt-2 border-t border-gray-100 dark:border-gray-700">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                        <i data-lucide="log-out" class="w-5 h-5"></i> Sign Out
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="flex-1">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">My Orders</h1>

        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $s = $statusConfig[$order->status] ?? $statusConfig['pending']; ?>
        <div class="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm mb-4 overflow-hidden hover:shadow-md transition-shadow">
            <!-- Order Header -->
            <div class="flex items-center justify-between px-5 py-4 border-b border-gray-50 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <i data-lucide="package" class="w-5 h-5 text-primary"></i>
                    </div>
                    <div>
                        <p class="font-bold text-gray-900 dark:text-white text-sm">Order #<?php echo e($order->id); ?></p>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($order->created_at->format('d M Y')); ?></p>
                    </div>
                </div>
                <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold <?php echo e($s['class']); ?>">
                    <i data-lucide="<?php echo e($s['icon']); ?>" class="w-3.5 h-3.5"></i>
                    <?php echo e($s['label']); ?>

                </span>
            </div>

            <!-- Status Progress Bar -->
            <?php
            $flow = ['pending', 'processing', 'shipped', 'delivered', 'completed'];
            $idx = array_search($order->status, $flow);
            $pct = ($idx !== false && $order->status !== 'cancelled') ? round(($idx / (count($flow)-1)) * 100) : 0;
            ?>
            <?php if($order->status !== 'cancelled'): ?>
            <div class="px-5 py-4 bg-gray-50/50 dark:bg-gray-900/20 border-b border-gray-50 dark:border-gray-700">
                <div class="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-2">
                    <?php $__currentLoopData = $flow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="<?php echo e(array_search($s2, $flow) <= $idx ? 'text-primary font-semibold' : ''); ?>"><?php echo e(ucfirst($s2)); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div class="h-full bg-primary rounded-full transition-all duration-700" style="width: <?php echo e($pct); ?>%"></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Items Preview -->
            <div class="px-5 py-4">
                <div class="flex items-center gap-3 flex-wrap">
                    <?php $__currentLoopData = $order->items->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 px-3 py-1.5 rounded-lg border border-gray-100 dark:border-gray-600">
                        <?php if($item->product && $item->product->thumbnail): ?>
                        <img src="<?php echo e($item->product->thumbnail->url); ?>" class="w-6 h-6 rounded object-cover">
                        <?php endif; ?>
                        <span class="text-xs font-medium text-gray-700 dark:text-gray-300">
                            <?php echo e(Str::limit($item->product_name, 20)); ?> <span class="text-gray-400">×<?php echo e($item->quantity); ?></span>
                        </span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($order->items->count() > 4): ?>
                    <span class="text-xs font-medium text-gray-400 bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-lg border border-gray-100 dark:border-gray-700">
                        +<?php echo e($order->items->count() - 4); ?> more
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Footer -->
            <div class="flex items-center justify-between px-5 py-4 border-t border-gray-50 dark:border-gray-700">
                <div>
                    <p class="text-xs text-gray-500 dark:text-gray-400">Total Amount</p>
                    <span class="font-bold text-gray-900 dark:text-white text-lg">৳<?php echo e(number_format($order->total_amount, 0)); ?></span>
                </div>
                <a href="<?php echo e(route('account.order_detail', $order)); ?>"
                   class="bg-gray-100 hover:bg-primary hover:text-white dark:bg-gray-700 dark:hover:bg-primary text-gray-700 dark:text-gray-200 px-4 py-2 rounded-xl text-sm font-semibold transition-colors flex items-center gap-2">
                    View Details <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-center py-20 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm">
            <div class="w-24 h-24 bg-gray-50 dark:bg-gray-900 rounded-full flex items-center justify-center mx-auto mb-5">
                <i data-lucide="package-open" class="w-12 h-12 text-gray-400"></i>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No orders yet</h3>
            <p class="text-gray-500 dark:text-gray-400 mb-8 max-w-sm mx-auto">Looks like you haven't made your first purchase yet. Discover our premium collection!</p>
            <a href="<?php echo e(route('shop.index')); ?>" class="inline-flex items-center gap-2 bg-primary text-white px-8 py-3.5 rounded-xl font-bold hover:bg-primary/90 transition-all hover:shadow-lg hover:shadow-primary/30 hover:-translate-y-0.5">
                <i data-lucide="shopping-bag" class="w-5 h-5"></i> Start Shopping
            </a>
        </div>
        <?php endif; ?>

        <?php if($orders->hasPages()): ?>
        <div class="mt-6"><?php echo e($orders->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/account/orders.blade.php ENDPATH**/ ?>