<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $data = $section->data ?? [];
    $faqs = $data['faqs'] ?? [];
    $title = $section->title ?? 'Frequently Asked Questions';
    $subtitle = $section->subtitle ?? 'Everything you need to know about our products and services.';
?>

<?php if(count($faqs) > 0): ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 my-8">
    
    <div class="text-center mb-12">
        <h2 class="text-3xl md:text-4xl font-extrabold text-gray-900 dark:text-white tracking-tight mb-4"><?php echo e($title); ?></h2>
        <?php if($subtitle): ?>
            <p class="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto"><?php echo e($subtitle); ?></p>
        <?php endif; ?>
    </div>

    <div class="space-y-4" x-data="{ activeAccordion: 0 }">
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden cursor-pointer" 
                 x-data="{ 
                    id: <?php echo e($index); ?>, 
                    get expanded() { return this.activeAccordion === this.id },
                    set expanded(value) { this.activeAccordion = value ? this.id : null }
                 }"
                 @click="expanded = !expanded">
                 
                <div class="flex justify-between items-center w-full px-6 py-5 text-left focus:outline-none">
                    <span class="text-lg font-semibold text-gray-900 dark:text-gray-100 pr-4 transition-colors duration-200" :class="{ 'text-primary dark:text-primary': expanded }">
                        <?php echo e($faq['question'] ?? ''); ?>

                    </span>
                    <span class="flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center bg-primary/5 text-primary transition-all duration-300" :class="{ '-rotate-180 bg-primary text-white': expanded }">
                        <i data-lucide="chevron-down" class="w-5 h-5"></i>
                    </span>
                </div>
                
                <div x-show="expanded" x-collapse x-cloak>
                    <div class="px-6 pb-6 pt-0 text-gray-600 dark:text-gray-400 leading-relaxed text-base border-t border-gray-50 dark:border-gray-700/50 mt-2">
                        <div class="pt-4 whitespace-pre-line"><?php echo e($faq['answer'] ?? ''); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</div>
<?php endif; ?>
<?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/components/faq-block.blade.php ENDPATH**/ ?>