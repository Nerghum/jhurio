<?php $__env->startSection('title', 'Jhurio - Handcrafted with Love'); ?>

<?php $__env->startSection('content'); ?>

<!-- Dynamic Sections (Homepage Builder) -->
<div class="space-y-12 pb-20 pt-4">



    <?php $__currentLoopData = $builderSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($section->type === 'hero'): ?>
            <?php if (isset($component)) { $__componentOriginal107194f055422bc1adb65f872fa83263 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal107194f055422bc1adb65f872fa83263 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero-block','data' => ['section' => $section,'categories' => $allCategories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section),'categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($allCategories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal107194f055422bc1adb65f872fa83263)): ?>
<?php $attributes = $__attributesOriginal107194f055422bc1adb65f872fa83263; ?>
<?php unset($__attributesOriginal107194f055422bc1adb65f872fa83263); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal107194f055422bc1adb65f872fa83263)): ?>
<?php $component = $__componentOriginal107194f055422bc1adb65f872fa83263; ?>
<?php unset($__componentOriginal107194f055422bc1adb65f872fa83263); ?>
<?php endif; ?>
        <?php elseif($section->type === 'flash_sale'): ?>
            <?php if (isset($component)) { $__componentOriginal9851b3111e1c4f17bcef82488c4f847a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9851b3111e1c4f17bcef82488c4f847a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-sale-block','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-sale-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9851b3111e1c4f17bcef82488c4f847a)): ?>
<?php $attributes = $__attributesOriginal9851b3111e1c4f17bcef82488c4f847a; ?>
<?php unset($__attributesOriginal9851b3111e1c4f17bcef82488c4f847a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9851b3111e1c4f17bcef82488c4f847a)): ?>
<?php $component = $__componentOriginal9851b3111e1c4f17bcef82488c4f847a; ?>
<?php unset($__componentOriginal9851b3111e1c4f17bcef82488c4f847a); ?>
<?php endif; ?>
        <?php elseif($section->type === 'image_text'): ?>
            <?php if (isset($component)) { $__componentOriginal8c8697bc5e846da5a69e00e33fc16d55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c8697bc5e846da5a69e00e33fc16d55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image-text-block','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-text-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c8697bc5e846da5a69e00e33fc16d55)): ?>
<?php $attributes = $__attributesOriginal8c8697bc5e846da5a69e00e33fc16d55; ?>
<?php unset($__attributesOriginal8c8697bc5e846da5a69e00e33fc16d55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c8697bc5e846da5a69e00e33fc16d55)): ?>
<?php $component = $__componentOriginal8c8697bc5e846da5a69e00e33fc16d55; ?>
<?php unset($__componentOriginal8c8697bc5e846da5a69e00e33fc16d55); ?>
<?php endif; ?>
        <?php elseif($section->type === 'faq'): ?>
            <?php if (isset($component)) { $__componentOriginal8a15a3755699e29026db1581f3ef0014 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a15a3755699e29026db1581f3ef0014 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq-block','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('faq-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a15a3755699e29026db1581f3ef0014)): ?>
<?php $attributes = $__attributesOriginal8a15a3755699e29026db1581f3ef0014; ?>
<?php unset($__attributesOriginal8a15a3755699e29026db1581f3ef0014); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a15a3755699e29026db1581f3ef0014)): ?>
<?php $component = $__componentOriginal8a15a3755699e29026db1581f3ef0014; ?>
<?php unset($__componentOriginal8a15a3755699e29026db1581f3ef0014); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal53ed3ff0cf28053f8f85af58fcc7d3f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53ed3ff0cf28053f8f85af58fcc7d3f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-block','data' => ['title' => $section->title,'subtitle' => $section->subtitle,'products' => $section->products,'highlight' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section->title),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section->subtitle),'products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section->products),'highlight' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53ed3ff0cf28053f8f85af58fcc7d3f1)): ?>
<?php $attributes = $__attributesOriginal53ed3ff0cf28053f8f85af58fcc7d3f1; ?>
<?php unset($__attributesOriginal53ed3ff0cf28053f8f85af58fcc7d3f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53ed3ff0cf28053f8f85af58fcc7d3f1)): ?>
<?php $component = $__componentOriginal53ed3ff0cf28053f8f85af58fcc7d3f1; ?>
<?php unset($__componentOriginal53ed3ff0cf28053f8f85af58fcc7d3f1); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/welcome.blade.php ENDPATH**/ ?>