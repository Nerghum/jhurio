<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section', 'categories']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section', 'categories']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $hero = $section->data['hero'] ?? [];
    $slider = $hero['slider'] ?? [];
    $rightTop = $hero['right_top'] ?? [];
    $rightBottom = $hero['right_bottom'] ?? [];
    $bottomStrip = $hero['bottom_strip'] ?? [];
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-12 gap-4">
        
        <!-- Part 1: Sidebar Categories -->
        <div class="hidden lg:block lg:col-span-3 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden h-[420px] flex flex-col">
            <div class="bg-primary text-white p-4 font-bold flex items-center space-x-2">
                <i data-lucide="list" class="w-5 h-5"></i>
                <span>Categories</span>
            </div>
            <ul class="flex-1 overflow-y-auto custom-scrollbar p-2">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('shop.index', ['category' => $category->slug])); ?>" class="flex items-center justify-between px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:text-primary dark:hover:text-primary hover:bg-gray-50 dark:hover:bg-gray-700/50 rounded-lg transition-colors group">
                            <span class="flex items-center space-x-2">
                                <span class="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600 group-hover:bg-primary transition-colors"></span>
                                <span><?php echo e($category->name); ?></span>
                            </span>
                            <?php if($category->products_count > 0): ?>
                                <span class="text-xs bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 px-2 py-0.5 rounded-full"><?php echo e($category->products_count); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Part 2: Main Slider -->
        <div class="col-span-12 md:col-span-12 lg:col-span-6 rounded-xl overflow-hidden shadow-sm relative h-[300px] lg:h-[420px] group bg-gray-100 dark:bg-gray-800">
            <?php if(!empty($slider['image'])): ?>
                <a href="<?php echo e($slider['link'] ?? '#'); ?>" class="block w-full h-full">
                    <img src="<?php echo e($slider['image']); ?>" class="w-full h-full object-cover" alt="Hero Banner">
                </a>
            <?php else: ?>
                <div class="w-full h-full flex flex-col items-center justify-center text-gray-400">
                    <i data-lucide="image" class="w-12 h-12 mb-2"></i>
                    <span>Configure Main Image</span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Parts 3 & 4: Right Side Static Banners -->
        <div class="hidden md:flex lg:flex md:col-span-12 lg:col-span-3 flex-row lg:flex-col gap-4 h-[200px] lg:h-[420px]">
            <!-- Top Banner -->
            <div class="flex-1 rounded-xl overflow-hidden shadow-sm relative group bg-gray-100 dark:bg-gray-800">
                <?php if(!empty($rightTop['image'])): ?>
                    <a href="<?php echo e($rightTop['link'] ?? '#'); ?>" class="block w-full h-full relative">
                        <img src="<?php echo e($rightTop['image']); ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt="Right Top Banner">
                        <div class="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                    </a>
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400 text-sm">Right Top Image</div>
                <?php endif; ?>
            </div>
            
            <!-- Bottom Banner -->
            <div class="flex-1 rounded-xl overflow-hidden shadow-sm relative group bg-gray-100 dark:bg-gray-800">
                <?php if(!empty($rightBottom['image'])): ?>
                    <a href="<?php echo e($rightBottom['link'] ?? '#'); ?>" class="block w-full h-full relative">
                        <img src="<?php echo e($rightBottom['image']); ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt="Right Bottom Banner">
                        <div class="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                    </a>
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400 text-sm">Right Bottom Image</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Part 5: Bottom Strip (Optional) -->
    <?php if(!empty($bottomStrip['image'])): ?>
        <div class="mt-4 rounded-xl overflow-hidden shadow-sm h-[100px] md:h-[120px] relative group">
            <a href="<?php echo e($bottomStrip['link'] ?? '#'); ?>" class="block w-full h-full">
                <img src="<?php echo e($bottomStrip['image']); ?>" class="w-full h-full object-cover" alt="Bottom Strip Banner">
            </a>
        </div>
    <?php endif; ?>
    
    <!-- Trust Badges Strip -->
    <div class="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
        <div class="flex items-center space-x-3 p-2">
            <div class="text-primary"><i data-lucide="truck" class="w-6 h-6"></i></div>
            <div><h4 class="text-sm font-semibold text-gray-900 dark:text-white">Free Delivery</h4><p class="text-xs text-gray-500">From BDT 5000</p></div>
        </div>
        <div class="flex items-center space-x-3 p-2">
            <div class="text-primary"><i data-lucide="refresh-cw" class="w-6 h-6"></i></div>
            <div><h4 class="text-sm font-semibold text-gray-900 dark:text-white">Easy Returns</h4><p class="text-xs text-gray-500">14 Days Return</p></div>
        </div>
        <div class="flex items-center space-x-3 p-2">
            <div class="text-primary"><i data-lucide="shield-check" class="w-6 h-6"></i></div>
            <div><h4 class="text-sm font-semibold text-gray-900 dark:text-white">Secure Payment</h4><p class="text-xs text-gray-500">100% Safe</p></div>
        </div>
        <div class="flex items-center space-x-3 p-2">
            <div class="text-primary"><i data-lucide="headphones" class="w-6 h-6"></i></div>
            <div><h4 class="text-sm font-semibold text-gray-900 dark:text-white">24/7 Support</h4><p class="text-xs text-gray-500">Dedicated Team</p></div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<style>
    .custom-scrollbar::-webkit-scrollbar {
        width: 4px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: #e5e7eb;
        border-radius: 20px;
    }
    .dark .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: #374151;
    }
</style>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/components/hero-block.blade.php ENDPATH**/ ?>