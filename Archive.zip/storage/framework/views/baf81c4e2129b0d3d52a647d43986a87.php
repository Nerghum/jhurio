<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $data = $section->data ?? [];
    $image = $data['image'] ?? '';
    $layout = $data['layout'] ?? 'left';
    $buttonText = $data['button_text'] ?? '';
    $buttonLink = $data['button_link'] ?? '#';
    $description = $data['description'] ?? '';
    $title = $section->title ?? '';
    $subtitle = $section->subtitle ?? '';
?>

<?php if($image || $title || $description): ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-12">
    <div class="bg-white dark:bg-gray-800 rounded-3xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
        <div class="flex flex-col <?php echo e($layout === 'right' ? 'md:flex-row-reverse' : 'md:flex-row'); ?> items-stretch">
            
            <!-- Image Side -->
            <?php if($image): ?>
            <div class="w-full md:w-1/2 h-64 md:h-auto md:min-h-[400px] relative">
                <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="absolute inset-0 w-full h-full object-cover">
            </div>
            <?php endif; ?>

            <!-- Content Side -->
            <div class="w-full <?php echo e($image ? 'md:w-1/2' : 'md:w-full'); ?> p-8 md:p-12 lg:p-16 flex flex-col justify-center">
                <?php if($subtitle): ?>
                    <span class="text-primary font-semibold tracking-wider uppercase text-sm mb-3"><?php echo e($subtitle); ?></span>
                <?php endif; ?>
                
                <?php if($title): ?>
                    <h2 class="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6 leading-tight"><?php echo e($title); ?></h2>
                <?php endif; ?>
                
                <?php if($description): ?>
                    <p class="text-gray-600 dark:text-gray-300 text-lg mb-8 leading-relaxed whitespace-pre-line"><?php echo e($description); ?></p>
                <?php endif; ?>
                
                <?php if($buttonText): ?>
                    <div>
                        <a href="<?php echo e($buttonLink); ?>" class="inline-flex items-center justify-center px-8 py-3 text-base font-medium text-white bg-primary rounded-xl hover:bg-secondary transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                            <?php echo e($buttonText); ?>

                            <i data-lucide="arrow-right" class="w-5 h-5 ml-2"></i>
                        </a>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/components/image-text-block.blade.php ENDPATH**/ ?>