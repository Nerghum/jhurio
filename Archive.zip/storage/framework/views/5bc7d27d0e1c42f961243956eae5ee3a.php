<?php $__env->startSection('header', 'Media Library'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-between items-center">
    <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Media Library</h2>
    <button @click="window.dispatchEvent(new CustomEvent('open-media-modal', { detail: { callbackEvent: null } }))" class="flex items-center px-4 py-2 bg-primary text-white rounded-xl hover:bg-secondary transition-colors">
        <i data-lucide="upload-cloud" class="w-4 h-4 mr-2"></i>
        Upload New
    </button>
</div>

<div class="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="relative group aspect-square rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900">
                <?php if(str_starts_with($item->file_type, 'image/')): ?>
                    <img src="<?php echo e($item->url); ?>" alt="<?php echo e($item->filename); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400">
                        <i data-lucide="file" class="w-12 h-12"></i>
                    </div>
                <?php endif; ?>
                <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <span class="text-white text-xs truncate px-2 text-center"><?php echo e($item->filename); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full py-16 text-center text-gray-500">
                <i data-lucide="image" class="mx-auto h-12 w-12 text-gray-400 mb-3"></i>
                <p>No media files found. Upload some to get started.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ashik/Desktop/personal work/jhurio/resources/views/admin/media/index.blade.php ENDPATH**/ ?>